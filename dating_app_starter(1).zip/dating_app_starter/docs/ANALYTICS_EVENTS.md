# События аналитики (MVP)
- app_open
- signup_complete
- verify_request / verify_pass / verify_fail
- view_candidate
- swipe_like / swipe_pass
- match
- chat_send
- report_submit
- purchase
